<div class="instafeed-placeholder">
	<ul>
		<li>
			<img src="<?php bloginfo('template_url'); ?>/assets/images/checker.png" alt="placeholder" />
		</li>
		<li>
			<img src="<?php bloginfo('template_url'); ?>/assets/images/checker.png" alt="placeholder" />
		</li>
		<li>
			<img src="<?php bloginfo('template_url'); ?>/assets/images/checker.png" alt="placeholder" />
		</li>
		<li>
			<img src="<?php bloginfo('template_url'); ?>/assets/images/checker.png" alt="placeholder" />
		</li>
		<li>
			<img src="<?php bloginfo('template_url'); ?>/assets/images/checker.png" alt="placeholder" />
		</li>
		<li>
			<img src="<?php bloginfo('template_url'); ?>/assets/images/checker.png" alt="placeholder" />
		</li>
		<li>
			<img src="<?php bloginfo('template_url'); ?>/assets/images/checker.png" alt="placeholder" />
		</li>
		<li>
			<img src="<?php bloginfo('template_url'); ?>/assets/images/checker.png" alt="placeholder" />
		</li>
		<li>
			<img src="<?php bloginfo('template_url'); ?>/assets/images/checker.png" alt="placeholder" />
		</li>
	</ul>
</div>