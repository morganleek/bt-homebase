<?php
// Post 2 Posts Connections
// function hb_connections() {
// 	p2p_register_connection_type(
// 		[ 
// 			'name'        => 'displays_to_photos',
// 			'from'        => 'display',
// 			'to'          => 'photo',
// 			'cardinality' => 'one-to-many',
// 		],
// 	);

// 	p2p_register_connection_type(
// 		[ 
// 			'name'     => 'inspire_boards_to_photos',
// 			'from'     => 'inspire-board',
// 			'to'       => 'photo',
// 			'sortable' => 'any',
// 		],
// 	);
// }

// add_action( 'p2p_init', 'hb_connections' );