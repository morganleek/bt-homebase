// const { registerBlockVariation } = wp.blocks;

// registerBlockVariation(
// 	'core/media-text',
// 	{
// 		name: 'group-grid',
// 		title: 'Grid',
// 		attributes: {
// 			align: 'wide',
// 		},
// 	}
// );